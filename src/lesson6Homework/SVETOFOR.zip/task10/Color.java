package lesson6Homework.task10;

public enum Color {

    STOP,
    WAIT,
    GO,
    ;


}
