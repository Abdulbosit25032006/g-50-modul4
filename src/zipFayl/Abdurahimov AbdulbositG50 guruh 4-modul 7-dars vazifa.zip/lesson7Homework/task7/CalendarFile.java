package lesson7Homework.task7;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class CalendarFile {
    public static void main(String[] args) {


        //todo endi yozaman

        try (
                Reader reader = new FileReader("C:\\Users\\O M E N\\Desktop\\JavaData\\Test");
                Writer writer = new FileWriter("C:\\Users\\O M E N\\Desktop\\JavaData")
        ) {






        }catch (Exception e){
            e.printStackTrace();
        }



    }
}
