package lesson4Homework.task4;

public class User {

}
