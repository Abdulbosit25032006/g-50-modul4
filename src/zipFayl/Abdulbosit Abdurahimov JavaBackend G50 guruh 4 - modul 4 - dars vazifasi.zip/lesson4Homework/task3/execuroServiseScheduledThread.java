package lesson4Homework.task3;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class execuroServiseScheduledThread {
    public static void main(String[] args) {

        ExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(1);

        Long begin = System.currentTimeMillis();
        Runnable task = () -> {
            SimpleDateFormat dataFarmatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            System.out.println("Joriy vaqt: " + dataFarmatted.format(new Date()));
        };


        for (int i = 0; i < 100; i++) {
            scheduledExecutorService.execute(task);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

        }

        long end = System.currentTimeMillis();
        scheduledExecutorService.shutdown();

        System.out.println(end - begin);

        scheduledExecutorService.shutdown();
    }
}
